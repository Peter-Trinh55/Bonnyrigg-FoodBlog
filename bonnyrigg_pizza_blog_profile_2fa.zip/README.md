# Bonnyrigg Pizza Blog - Profile + 2FA Version

This version adds:
- profile page
- profile picture upload
- username change
- password change
- 6 digit verification for login
- 6 digit verification for password reset
- support for either Gmail/email verification or authenticator app verification

## Important Gmail setup
To actually send Gmail verification codes, set these environment variables before running the app:

GMAIL_ADDRESS=yourgmail@gmail.com
GMAIL_APP_PASSWORD=your_google_app_password

If you do not configure Gmail, the app still works for testing:
- email codes are printed in the terminal
- authenticator app codes still work normally

## Authenticator app setup
1. Log in
2. Go to Profile
3. Enable authenticator app 2FA
4. Copy the manual secret key into Google Authenticator or another authenticator app
5. Use the 6 digit code from that app during future logins or password resets

## Run
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py

## Default admin login
Email: admin@bonnyriggpizza.local
Password: PizzaPass123
