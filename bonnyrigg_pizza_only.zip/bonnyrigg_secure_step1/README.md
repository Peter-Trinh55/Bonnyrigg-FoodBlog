# Bonnyrigg Pizza Blog – Step 1 Security Upgrade

This version focuses on the **Task 2 security requirements** before moving to the visual upgrades and documentation alignment.

## Security features added
- Password hashing using Werkzeug
- Two-factor authentication using `pyotp`
- CSRF protection using `Flask-WTF`
- Brute-force mitigation using `Flask-Limiter`
- Secure session settings and timed expiry
- Role-based admin access control
- Input sanitisation using `bleach`
- Graceful 403, 404, and 500 error pages
- SQLite database with SQLAlchemy ORM to help prevent SQL injection

## How to run in VS Code
1. Extract the folder.
2. Open the project folder in Visual Studio Code.
3. Open a new terminal.
4. Create a virtual environment:
   - Windows: `python -m venv venv`
   - Then: `venv\Scripts\activate`
5. Install packages:
   - `pip install -r requirements.txt`
6. Start the app:
   - `python app.py`
7. Open:
   - `http://127.0.0.1:5000`

## Default seeded admin account
- Email: `admin@bonnyriggpizza.local`
- Password: `PizzaPass123`

## Important note for 2FA
The first time you register a new account, the app displays a manual secret and provisioning URI.
Add the account to Google Authenticator or Microsoft Authenticator, then use the 6-digit code on login.

## What to improve next
- Step 2: make the site look much more polished and closer to a real food blog
- Step 3: align README and project documentation to the appendix and assessment wording
