import os
import secrets
from datetime import timedelta

import bleach
import pyotp
from flask import Flask, abort, flash, redirect, render_template, request, session, url_for
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from flask_wtf.csrf import CSRFProtect
from markupsafe import Markup
from sqlalchemy import func
from werkzeug.security import check_password_hash, generate_password_hash
from wtforms import PasswordField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError

# Create the Flask application.
app = Flask(__name__, instance_relative_config=True)

# Store secret values in environment variables where possible.
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(16))

# Use a local SQLite database so the project runs easily in VS Code.
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'sqlite:///' + os.path.join(app.instance_path, 'site.db')
)

# Reduce unnecessary overhead and strengthen cookie security.
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['REMEMBER_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=20)

# Turn on secure cookies automatically when the app is served over HTTPS.
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('FLASK_ENV') == 'production'
app.config['REMEMBER_COOKIE_SECURE'] = os.environ.get('FLASK_ENV') == 'production'

# Initialise major Flask extensions.
db = SQLAlchemy(app)
csrf = CSRFProtect(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'warning'
limiter = Limiter(key_func=get_remote_address, default_limits=['200 per day', '50 per hour'])
limiter.init_app(app)

# Ensure the SQLite folder exists before the first run.
os.makedirs(app.instance_path, exist_ok=True)

# Keep the list of cuisine choices short and consistent.
CUISINES = ['Italian', 'Mexican', 'Asian', 'Australian', 'Vegetarian', 'Dessert']


# Define the user account table.
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')
    otp_secret = db.Column(db.String(32), nullable=False, default=lambda: pyotp.random_base32())
    created_at = db.Column(db.DateTime, server_default=func.now(), nullable=False)
    recipes = db.relationship('Recipe', backref='author', lazy=True)

    # Hash passwords before they are stored.
    def set_password(self, raw_password: str) -> None:
        self.password_hash = generate_password_hash(raw_password)

    # Compare the submitted password to the saved hash.
    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    # Create a TOTP object for two-factor verification.
    def totp(self):
        return pyotp.TOTP(self.otp_secret)


# Define the recipe table.
class Recipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    cuisine = db.Column(db.String(30), nullable=False)
    ingredients = db.Column(db.Text, nullable=False)
    instructions = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(255), nullable=False, default='https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80')
    created_at = db.Column(db.DateTime, server_default=func.now(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


# Load the logged-in user from the session.
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# Sanitize text so comment-like fields cannot inject scripts.
def clean_text(value: str, max_length: int = 5000) -> str:
    if not value:
        return ''
    trimmed = value.strip()[:max_length]
    return bleach.clean(trimmed, tags=[], strip=True)


# Check whether the current user is an administrator.
def admin_required():
    if not current_user.is_authenticated or current_user.role != 'admin':
        abort(403)


# Create the registration form.
class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=30)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=64)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Create Account')

    # Prevent duplicate usernames.
    def validate_username(self, username):
        if User.query.filter_by(username=username.data.strip()).first():
            raise ValidationError('That username is already taken.')

    # Prevent duplicate emails.
    def validate_email(self, email):
        if User.query.filter_by(email=email.data.strip().lower()).first():
            raise ValidationError('That email is already registered.')


# Create the first login step form.
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=64)])
    submit = SubmitField('Continue to 2FA')


# Create the second login step form.
class OTPForm(FlaskForm):
    code = StringField('Authenticator Code', validators=[DataRequired(), Length(min=6, max=6)])
    submit = SubmitField('Verify and Log In')


# Create the recipe form used by admins.
class RecipeForm(FlaskForm):
    title = StringField('Recipe Title', validators=[DataRequired(), Length(min=3, max=120)])
    cuisine = StringField('Cuisine', validators=[DataRequired(), Length(min=3, max=30)])
    ingredients = TextAreaField('Ingredients', validators=[DataRequired(), Length(min=10, max=2500)])
    instructions = TextAreaField('Instructions', validators=[DataRequired(), Length(min=20, max=5000)])
    image_url = StringField('Image URL', validators=[Length(max=255)])
    submit = SubmitField('Save Recipe')


# Show the homepage with the latest recipes.
@app.route('/')
def home():
    selected_cuisine = request.args.get('cuisine', '').strip()
    query = Recipe.query.order_by(Recipe.created_at.desc())

    # Filter by cuisine when the user selects one.
    if selected_cuisine:
        query = query.filter_by(cuisine=selected_cuisine)

    recipes = query.all()
    return render_template('home.html', recipes=recipes, cuisines=CUISINES, selected_cuisine=selected_cuisine)


# Register a new account with secure validation.
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))

    form = RegisterForm()

    # Save the account only after validation passes.
    if form.validate_on_submit():
        user = User(
            username=clean_text(form.username.data, 30),
            email=clean_text(form.email.data.lower(), 120),
            role='admin' if User.query.count() == 0 else 'user'
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Account created. Set up your authenticator app using the secret on the next page.', 'success')
        return redirect(url_for('setup_2fa', user_id=user.id))

    return render_template('register.html', form=form)


# Display the 2FA secret after registration.
@app.route('/setup-2fa/<int:user_id>')
def setup_2fa(user_id):
    user = db.session.get(User, user_id)
    if not user:
        abort(404)
    otp_uri = user.totp().provisioning_uri(name=user.email, issuer_name='Bonnyrigg Pizza Blog')
    return render_template('setup_2fa.html', user=user, otp_uri=otp_uri)


# Start the login process.
@app.route('/login', methods=['GET', 'POST'])
@limiter.limit('5 per minute')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))

    form = LoginForm()

    # Validate the first factor before asking for the one-time code.
    if form.validate_on_submit():
        user = User.query.filter_by(email=clean_text(form.email.data.lower(), 120)).first()

        if user and user.check_password(form.password.data):
            session['pre_2fa_user_id'] = user.id
            session.permanent = True
            flash('Password accepted. Enter the 6-digit authenticator code.', 'info')
            return redirect(url_for('verify_2fa'))

        flash('Login failed. Check your email and password.', 'danger')

    return render_template('login.html', form=form)


# Complete the second login factor.
@app.route('/verify-2fa', methods=['GET', 'POST'])
@limiter.limit('5 per minute')
def verify_2fa():
    pre_2fa_user_id = session.get('pre_2fa_user_id')
    if not pre_2fa_user_id:
        return redirect(url_for('login'))

    user = db.session.get(User, pre_2fa_user_id)
    if not user:
        session.pop('pre_2fa_user_id', None)
        return redirect(url_for('login'))

    form = OTPForm()

    # Accept the code only when it matches the current TOTP window.
    if form.validate_on_submit():
        code = clean_text(form.code.data, 6)

        if user.totp().verify(code, valid_window=1):
            login_user(user)
            session.pop('pre_2fa_user_id', None)
            session.permanent = True
            flash('You are now logged in securely.', 'success')
            return redirect(url_for('home'))

        flash('Invalid authenticator code.', 'danger')

    return render_template('verify_2fa.html', form=form)


# Safely log the user out and clear session values.
@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()
    flash('Your session has been ended safely.', 'info')
    return redirect(url_for('home'))


# Show a recipe details page.
@app.route('/recipe/<int:recipe_id>')
def recipe_detail(recipe_id):
    recipe = db.session.get(Recipe, recipe_id)
    if not recipe:
        abort(404)
    return render_template('recipe_detail.html', recipe=recipe)


# Manage content from a restricted admin page.
@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin_dashboard():
    admin_required()
    form = RecipeForm()

    # Only save recipes that pass form validation.
    if form.validate_on_submit():
        cuisine = clean_text(form.cuisine.data, 30)
        if cuisine not in CUISINES:
            flash('Cuisine must match the approved category list.', 'danger')
            return redirect(url_for('admin_dashboard'))

        recipe = Recipe(
            title=clean_text(form.title.data, 120),
            cuisine=cuisine,
            ingredients=clean_text(form.ingredients.data, 2500),
            instructions=clean_text(form.instructions.data, 5000),
            image_url=clean_text(form.image_url.data, 255) or 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80',
            author=current_user
        )
        db.session.add(recipe)
        db.session.commit()
        flash('Recipe saved successfully.', 'success')
        return redirect(url_for('admin_dashboard'))

    recipes = Recipe.query.order_by(Recipe.created_at.desc()).all()
    return render_template('admin.html', form=form, recipes=recipes, cuisines=CUISINES)


# Delete a recipe securely with CSRF protection.
@app.route('/delete-recipe/<int:recipe_id>', methods=['POST'])
@login_required
def delete_recipe(recipe_id):
    admin_required()
    recipe = db.session.get(Recipe, recipe_id)
    if not recipe:
        abort(404)
    db.session.delete(recipe)
    db.session.commit()
    flash('Recipe deleted.', 'info')
    return redirect(url_for('admin_dashboard'))


# Return a friendly error page for forbidden requests.
@app.errorhandler(403)
def forbidden(_error):
    return render_template('error.html', code=403, message='You do not have permission to access that page.'), 403


# Return a friendly error page for missing pages.
@app.errorhandler(404)
def not_found(_error):
    return render_template('error.html', code=404, message='The page you requested could not be found.'), 404


# Avoid exposing internal details during unexpected errors.
@app.errorhandler(500)
def server_error(_error):
    db.session.rollback()
    return render_template('error.html', code=500, message='A server error occurred. Please try again later.'), 500


# Seed starter data so the project looks complete quickly.
def seed_data():
    if User.query.count() > 0:
        return

    admin_user = User(username='admin', email='admin@bonnyriggpizza.local', role='admin')
    admin_user.set_password('PizzaPass123')
    db.session.add(admin_user)
    db.session.flush()

    starter_recipes = [
        Recipe(
            title='Classic Margherita Pizza',
            cuisine='Italian',
            ingredients='Pizza dough, tomato sauce, mozzarella, basil, olive oil',
            instructions='Roll the dough. Spread sauce. Add mozzarella. Bake until golden. Finish with basil and olive oil.',
            image_url='https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=900&q=80',
            author=admin_user,
        ),
        Recipe(
            title='Spicy Mexican Pizza',
            cuisine='Mexican',
            ingredients='Flatbread, salsa, cheese, capsicum, onion, jalapenos',
            instructions='Layer salsa over the base. Add toppings and cheese. Bake until crisp and bubbling. Slice and serve.',
            image_url='https://images.unsplash.com/photo-1511689660979-10d2b1aada49?auto=format&fit=crop&w=900&q=80',
            author=admin_user,
        ),
    ]

    db.session.add_all(starter_recipes)
    db.session.commit()


# Build the database before the first request.
with app.app_context():
    db.create_all()
    seed_data()


# Run locally in VS Code.
if __name__ == '__main__':
    app.run(debug=True)
