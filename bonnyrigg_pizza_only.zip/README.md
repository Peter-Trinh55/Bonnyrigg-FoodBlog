# Bonnyrigg Pizza Blog - Pizza Only Version

This version is now strictly focused on pizza recipes only.

## Where to add recipe images
Put your image files inside:

static/images/

Examples:
- margherita.jpg
- pepperoni.jpg
- bbq_chicken.jpg
- vegetarian_supreme.jpg
- hawaiian.jpg
- meat_lovers.jpg

When adding a recipe in the admin dashboard, type the exact image filename into the image filename field.

## How to run in VS Code
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py

Open:
http://127.0.0.1:5000

## Seeded admin login
Email: admin@bonnyriggpizza.local
Password: PizzaPass123
