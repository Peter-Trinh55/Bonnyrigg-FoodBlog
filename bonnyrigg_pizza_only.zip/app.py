import os, secrets
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# Create the Flask application
app = Flask(__name__)

# Configure the secret key for sessions and flash messages
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', secrets.token_hex(16))

# Configure the SQLite database location
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bonnyrigg.db'

# Disable modification tracking to improve performance
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Secure session cookie settings
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Initialise the database object
db = SQLAlchemy(app)

# User model for authentication and admin access
class User(db.Model):
    # Primary key for each user
    id = db.Column(db.Integer, primary_key=True)

    # Public username shown in the app
    username = db.Column(db.String(80), nullable=False)

    # Unique email used for login
    email = db.Column(db.String(120), unique=True, nullable=False)

    # Hashed password for secure storage
    password_hash = db.Column(db.String(255), nullable=False)

    # Boolean flag for admin access
    is_admin = db.Column(db.Boolean, default=False)

# Recipe model used for pizza recipes only
class Recipe(db.Model):
    # Primary key for each recipe
    id = db.Column(db.Integer, primary_key=True)

    # Recipe title displayed on cards and admin table
    title = db.Column(db.String(120), nullable=False)

    # Pizza style or category
    pizza_type = db.Column(db.String(50), nullable=False, default='Classic')

    # Difficulty level for the recipe
    difficulty = db.Column(db.String(20), nullable=False, default='Easy')

    # Cook time in minutes
    cook_time = db.Column(db.Integer, nullable=False, default=25)

    # Main text describing ingredients or method
    description = db.Column(db.Text, nullable=False)

    # Image filename stored from the static/images folder
    image_filename = db.Column(db.String(120), nullable=False, default='default_pizza.jpg')

# Seed default content so the website looks full immediately
def seed_data():
    # Create a default admin account if it does not already exist
    if not User.query.filter_by(email='admin@bonnyriggpizza.local').first():
        db.session.add(
            User(
                username='admin',
                email='admin@bonnyriggpizza.local',
                password_hash=generate_password_hash('PizzaPass123'),
                is_admin=True
            )
        )

    # Add starter pizza recipes if the database is empty
    if Recipe.query.count() == 0:
        db.session.add_all([
            Recipe(
                title='Classic Margherita Pizza',
                pizza_type='Classic',
                difficulty='Easy',
                cook_time=20,
                description='Fresh tomato base, mozzarella, basil and a crisp golden crust.',
                image_filename='margherita.jpg'
            ),
            Recipe(
                title='Pepperoni Feast Pizza',
                pizza_type='Meat',
                difficulty='Easy',
                cook_time=22,
                description='Loaded pepperoni, cheese and rich tomato sauce for a bold flavour.',
                image_filename='pepperoni.jpg'
            ),
            Recipe(
                title='BBQ Chicken Pizza',
                pizza_type='Specialty',
                difficulty='Medium',
                cook_time=25,
                description='Smoky barbecue sauce, chicken, onion and melted cheese.',
                image_filename='bbq_chicken.jpg'
            ),
            Recipe(
                title='Vegetarian Supreme Pizza',
                pizza_type='Vegetarian',
                difficulty='Medium',
                cook_time=24,
                description='Capsicum, mushrooms, onion, olives and mozzarella on tomato sauce.',
                image_filename='vegetarian_supreme.jpg'
            ),
            Recipe(
                title='Hawaiian Pizza',
                pizza_type='Classic',
                difficulty='Easy',
                cook_time=20,
                description='Ham, pineapple, mozzarella and tomato sauce on a soft pizza base.',
                image_filename='hawaiian.jpg'
            ),
            Recipe(
                title='Meat Lovers Pizza',
                pizza_type='Meat',
                difficulty='Medium',
                cook_time=28,
                description='Pepperoni, ham, sausage, bacon and extra cheese for a hearty pizza.',
                image_filename='meat_lovers.jpg'
            )
        ])

    # Commit the default records to the database
    db.session.commit()

# Home route with pizza-only search and filtering
@app.route('/')
def home():
    # Start with the full recipe query
    query = Recipe.query

    # Read search input from the URL
    q = request.args.get('q', '').strip()

    # Read pizza type filter from the URL
    pizza_type = request.args.get('pizza_type', '').strip()

    # Read difficulty filter from the URL
    difficulty = request.args.get('difficulty', '').strip()

    # Filter by title or description if a search term exists
    if q:
        query = query.filter(Recipe.title.ilike(f'%{q}%') | Recipe.description.ilike(f'%{q}%'))

    # Filter by pizza type if selected
    if pizza_type:
        query = query.filter_by(pizza_type=pizza_type)

    # Filter by difficulty if selected
    if difficulty:
        query = query.filter_by(difficulty=difficulty)

    # Order recipes alphabetically for a clean layout
    recipes = query.order_by(Recipe.title.asc()).all()

    # Render the homepage template
    return render_template('home.html', recipes=recipes)

# Registration route for new accounts
@app.route('/register', methods=['GET', 'POST'])
def register():
    # Handle the submitted registration form
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        # Validate the required fields
        if not username or not email or not password:
            flash('Please fill in all required fields.', 'danger')
            return redirect(url_for('register'))

        # Prevent duplicate accounts with the same email
        if User.query.filter_by(email=email).first():
            flash('That email is already registered.', 'danger')
            return redirect(url_for('register'))

        # Create and store the new user
        db.session.add(
            User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password)
            )
        )
        db.session.commit()

        # Inform the user that registration succeeded
        flash('Account created successfully.', 'success')
        return redirect(url_for('login'))

    # Show the registration page
    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Handle submitted login form
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        # Look up the user by email
        user = User.query.filter_by(email=email).first()

        # Verify the password hash
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['is_admin'] = user.is_admin
            flash('Logged in successfully.', 'success')
            return redirect(url_for('admin_dashboard') if user.is_admin else url_for('home'))

        # Show an error if login failed
        flash('Invalid login details.', 'danger')
        return redirect(url_for('login'))

    # Show the login template
    return render_template('login.html', two_factor_required=False)

# Logout route
@app.route('/logout')
def logout():
    # Clear the user session safely
    session.clear()

    # Show a confirmation message
    flash('You have been logged out.', 'success')
    return redirect(url_for('home'))

# Protected admin dashboard
@app.route('/admin')
def admin_dashboard():
    # Restrict access to admins only
    if not session.get('is_admin'):
        flash('Admin access required.', 'danger')
        return redirect(url_for('login'))

    # Load recipes in newest-first order
    recipes = Recipe.query.order_by(Recipe.id.desc()).all()

    # Render the admin page
    return render_template('admin.html', recipes=recipes, users_count=User.query.count())

# Route to add a new pizza recipe
@app.route('/admin/add', methods=['POST'])
def add_recipe():
    # Restrict this action to admins only
    if not session.get('is_admin'):
        flash('Admin access required.', 'danger')
        return redirect(url_for('login'))

    # Read submitted fields from the form
    title = request.form.get('title', '').strip()
    pizza_type = request.form.get('pizza_type', '').strip()
    difficulty = request.form.get('difficulty', '').strip()
    description = request.form.get('description', '').strip()
    image_filename = request.form.get('image_filename', '').strip()

    # Validate the cook time value safely
    try:
        cook_time = int(request.form.get('cook_time', '0'))
    except ValueError:
        cook_time = 0

    # Validate required fields before saving
    if not title or not pizza_type or not difficulty or not description or cook_time <= 0:
        flash('Please complete all recipe fields correctly.', 'danger')
        return redirect(url_for('admin_dashboard'))

    # Use a default image if none was entered
    if not image_filename:
        image_filename = 'default_pizza.jpg'

    # Create the new pizza recipe record
    db.session.add(
        Recipe(
            title=title,
            pizza_type=pizza_type,
            difficulty=difficulty,
            cook_time=cook_time,
            description=description,
            image_filename=image_filename
        )
    )
    db.session.commit()

    # Show a success message after saving
    flash('Pizza recipe added successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

# Start the application
if __name__ == '__main__':
    # Create database tables and seed starter content
    with app.app_context():
        db.create_all()
        seed_data()

    # Run the Flask development server
    app.run(debug=True)
