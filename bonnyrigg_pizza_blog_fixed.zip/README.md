# Bonnyrigg Pizza Blog - Fixed Version

This version fixes the broken HTML template quoting that caused:
- plain unstyled page output
- image URLs ending with an extra slash
- CSS and images not loading correctly

Add your real images into static/images/ and run the app as normal.
