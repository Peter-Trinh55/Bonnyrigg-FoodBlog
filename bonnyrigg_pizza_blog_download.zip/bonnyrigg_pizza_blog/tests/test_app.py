import pathlib
import sys

sys.path.append(str(pathlib.Path(__file__).resolve().parents[1]))

from app import app


def test_homepage_loads():
    client = app.test_client()
    response = client.get('/')
    assert response.status_code == 200
    assert b'Bonnyrigg Pizza Blog' in response.data


def test_recipes_page_loads():
    client = app.test_client()
    response = client.get('/recipes')
    assert response.status_code == 200
