// Small client-side enhancement.
// This keeps the JavaScript footprint minimal for performance.
// The script adds the current year to the console for easy debugging.
console.debug('Bonnyrigg Pizza Blog loaded at', new Date().toISOString());
