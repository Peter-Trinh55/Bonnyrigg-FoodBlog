# Bonnyrigg Pizza Blog

A secure Flask + SQLite food blog built for the Bonnyrigg High School Software Engineering assessment tasks.

## Included features

- Home page with featured recipes, latest recipes, highlights, and school-style branding
- Recipe pages with title, image, ingredients, instructions, tags, difficulty, and cooking time
- Search and filter by keyword, cuisine, difficulty, and cooking time
- Blog section for cooking tips, nutrition advice, and seasonal meal ideas
- Community comments for signed-in users
- Admin dashboard for recipe management and comment moderation
- Responsive layout for desktop and mobile devices
- SQLite database
- CSRF protection via Flask-WTF
- Password hashing via Werkzeug
- 2FA via `pyotp`
- Session timeout and secure session cookie settings
- Parameterised SQL queries to help prevent SQL injection
- Input sanitisation to help reduce XSS risk
- Basic brute-force protection through failed-login tracking
- Graceful error pages
- Optional HTTPS support for local testing using an adhoc SSL certificate

## Default admin account

- Username: `admin`
- Password: `Admin123!`

Change this password before any real deployment.

## How to run in Visual Studio Code

### 1. Open the folder

Open the extracted `bonnyrigg_pizza_blog` folder in Visual Studio Code.

### 2. Create a virtual environment

#### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

#### Windows Command Prompt

```cmd
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install the packages

```bash
pip install -r requirements.txt
```

### 4. Run the app

```bash
python app.py
```

Open the local URL shown in the terminal, usually:

```text
http://127.0.0.1:5000
```

## Run with local HTTPS

To demonstrate HTTPS/SSL locally:

### Windows PowerShell

```powershell
$env:USE_HTTPS="true"
python app.py
```

### Windows Command Prompt

```cmd
set USE_HTTPS=true
python app.py
```

Then open:

```text
https://127.0.0.1:5000
```

Your browser may warn that the certificate is self-signed. That is normal for local testing.

## Project structure

```text
bonnyrigg_pizza_blog/
│
├── app.py
├── requirements.txt
├── README.md
├── instance/
│   └── blog.db
├── templates/
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── tests/
│   └── test_app.py
└── docs/
    └── REQUIREMENTS_TRACEABILITY.md
```

## Notes for assessment

- The app uses SQLite directly through Python's `sqlite3` module.
- The code is heavily commented to support collaboration and readability.
- Security features are visible in `app.py`, especially around authentication, validation, session handling, and database access.
- The website can be demonstrated in VS Code and locally hosted through Flask.
- Placeholder images are included so the website looks complete immediately. You can replace them with real food images later by placing new files in `static/images/`.

## Suggested next improvements

- Add email-based password reset
- Add QR code generation for 2FA setup
- Add richer moderation and audit screens
- Deploy to Render or PythonAnywhere for live hosting
