# Requirements Traceability

## Task 1 feature coverage

- **Home page with featured recipes, latest posts, highlights, school logo style**
  - Implemented on `/`
- **Recipe publishing with images, ingredients, instructions, tags**
  - Implemented through admin recipe creation and recipe detail pages
- **Search & filter by cuisine, difficulty, cooking time, ingredients/keywords**
  - Implemented on `/recipes`
- **Blog section for tips, nutrition, seasonal meals**
  - Implemented on `/blog`
- **Community interaction through comments and sharing**
  - Comment form on recipe pages and social share links
- **Admin dashboard for managing posts and moderating comments**
  - Implemented on `/admin`
- **Responsive design**
  - Implemented through `static/css/style.css`
- **SQLite database**
  - Implemented in `instance/blog.db` and `app.py`

## Task 2 security coverage

- **Threat identification / secure architecture**
  - Reflected through authentication, validation, session controls, and database protections
- **2FA**
  - Implemented using `pyotp`
- **CSRF protection**
  - Implemented with Flask-WTF form tokens
- **XSS reduction**
  - Implemented through `bleach.clean()` and Jinja escaping
- **Session management**
  - Timeout logic in `before_request`
- **Brute force mitigation**
  - Failed login tracking and temporary lockout logic
- **Privacy / confidentiality**
  - Minimal session storage, hashed passwords, secure headers
- **Data validation**
  - Implemented in WTForms validators and sanitising helpers
- **Graceful error handling**
  - Custom 400/403/404/500 pages
- **HTTPS / SSL**
  - Local adhoc SSL support through `USE_HTTPS=true`
- **SQL injection prevention**
  - Parameterised SQLite queries only
- **Password hashing**
  - Implemented using Werkzeug password hash helpers

## Documentation support

- README explains setup and deployment in Visual Studio Code
- Code is commented heavily throughout `app.py`
- Folder structure is clear and teacher-friendly
