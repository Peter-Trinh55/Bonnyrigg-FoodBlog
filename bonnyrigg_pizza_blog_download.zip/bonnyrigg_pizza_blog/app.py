import os
import re
import secrets
import sqlite3
from datetime import datetime, timedelta
from functools import wraps
from urllib.parse import quote_plus

import bleach
import pyotp
from flask import (
    Flask,
    abort,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_wtf import FlaskForm
from wtforms import BooleanField, PasswordField, SelectField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional, ValidationError
from werkzeug.security import check_password_hash, generate_password_hash

# -----------------------------------------------------------------------------
# Application configuration
# -----------------------------------------------------------------------------
# This project is written to satisfy the Bonnyrigg Pizza Blog / Cooking Blog task.
# The app is intentionally lightweight so it can be opened and run in VS Code.
# Security features such as CSRF, 2FA, rate limiting, validation, and sessions are included.
# -----------------------------------------------------------------------------

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, "instance", "blog.db")

# These constants make the application easier to maintain.
# Keeping them together avoids magic numbers spread through the code.
# This also improves readability for teachers and teammates.
SESSION_TIMEOUT_MINUTES = 30
MAX_LOGIN_ATTEMPTS = 5
LOGIN_WINDOW_MINUTES = 15
LOCKOUT_MINUTES = 15


# -----------------------------------------------------------------------------
# Flask application factory
# -----------------------------------------------------------------------------
# The create_app pattern helps organise configuration cleanly.
# It also makes testing easier because each test can create a new app instance.
# This follows good modular design practice from the assessment criteria.
# -----------------------------------------------------------------------------

def create_app() -> Flask:
    app = Flask(__name__, instance_relative_config=True)

    # Secret keys should not be hardcoded in production.
    # For school use, a default fallback is provided to keep local setup simple.
    # The README explains how to override these values with environment variables.
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-this-secret-key")
    app.config["WTF_CSRF_TIME_LIMIT"] = None
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = os.environ.get("FLASK_ENV") == "production"
    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=SESSION_TIMEOUT_MINUTES)

    # Ensure the instance folder exists before database setup.
    # SQLite stores its database file in instance/blog.db.
    # Using instance keeps mutable app data separate from source code.
    os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)

    # Register request lifecycle handlers.
    # These functions protect session state and add security headers.
    # They run for every request unless the app returns early.
    register_request_hooks(app)
    app.teardown_appcontext(close_db)

    # Register all routes in one place.
    # This keeps the application setup readable.
    # It also helps teachers find the route section quickly.
    register_routes(app)

    # Create the database if it does not exist yet.
    # Seed sample content so the website looks complete on first run.
    # This makes the project easier to demonstrate in class.
    with app.app_context():
        init_db()
        seed_data()

    return app


# -----------------------------------------------------------------------------
# Database helpers
# -----------------------------------------------------------------------------
# These helpers centralise all database access logic.
# Using parameterised queries protects the app against SQL injection.
# The row factory allows template code to access columns by name.
# -----------------------------------------------------------------------------

def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(_exception=None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


# -----------------------------------------------------------------------------
# Database schema creation
# -----------------------------------------------------------------------------
# The schema uses SQLite tables for users, recipes, comments, blog posts, and logs.
# This meets the task requirement to use SQLite for storage.
# The schema is created automatically so the marker can run it immediately.
# -----------------------------------------------------------------------------

def init_db() -> None:
    db = get_db()
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            two_factor_secret TEXT,
            two_factor_enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            cuisine TEXT NOT NULL,
            difficulty TEXT NOT NULL,
            cook_time INTEGER NOT NULL,
            ingredients TEXT NOT NULL,
            instructions TEXT NOT NULL,
            tags TEXT NOT NULL,
            image_name TEXT NOT NULL,
            excerpt TEXT NOT NULL,
            featured INTEGER NOT NULL DEFAULT 0,
            created_by INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY (created_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            approved INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            FOREIGN KEY (recipe_id) REFERENCES recipes(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS blog_posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            category TEXT NOT NULL,
            excerpt TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS login_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username_or_email TEXT NOT NULL,
            ip_address TEXT NOT NULL,
            successful INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    db.commit()


# -----------------------------------------------------------------------------
# Seeding helpers
# -----------------------------------------------------------------------------
# Seeding produces a polished demonstration site immediately.
# The recipes and blog posts are aligned with the cooking blog brief.
# This means the teacher does not see an empty website after first launch.
# -----------------------------------------------------------------------------

def seed_data() -> None:
    db = get_db()

    admin_exists = db.execute("SELECT id FROM users WHERE username = ?", ("admin",)).fetchone()
    if not admin_exists:
        db.execute(
            """
            INSERT INTO users (full_name, username, email, password_hash, is_admin, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                "Bonnyrigg Admin",
                "admin",
                "admin@bonnyriggpizzablog.local",
                generate_password_hash("Admin123!"),
                1,
                now_iso(),
            ),
        )
        db.commit()

    recipe_count = db.execute("SELECT COUNT(*) AS total FROM recipes").fetchone()["total"]
    if recipe_count == 0:
        admin_id = db.execute("SELECT id FROM users WHERE username = ?", ("admin",)).fetchone()["id"]
        recipes = [
            {
                "title": "Classic Margherita Pizza",
                "slug": "classic-margherita-pizza",
                "cuisine": "Italian",
                "difficulty": "Easy",
                "cook_time": 30,
                "ingredients": "Pizza dough\n1/2 cup tomato sauce\n200 g mozzarella\nFresh basil leaves\n1 tbsp olive oil\nPinch of salt",
                "instructions": "1. Preheat oven to 230°C.\n2. Stretch dough into a pizza base.\n3. Spread tomato sauce evenly.\n4. Add mozzarella and drizzle olive oil.\n5. Bake for 10 to 12 minutes until golden.\n6. Top with basil and serve hot.",
                "tags": "pizza,italian,vegetarian,quick",
                "image_name": "margherita.svg",
                "excerpt": "A simple Bonnyrigg favourite with fresh basil, mozzarella, and a crisp base.",
                "featured": 1,
            },
            {
                "title": "Spaghetti Bolognese",
                "slug": "spaghetti-bolognese",
                "cuisine": "Italian",
                "difficulty": "Medium",
                "cook_time": 45,
                "ingredients": "400 g spaghetti\n500 g beef mince\n1 onion, diced\n2 garlic cloves\n400 g crushed tomatoes\n2 tbsp tomato paste\n1 carrot, grated\nSalt and pepper",
                "instructions": "1. Cook spaghetti according to packet directions.\n2. Brown mince with onion and garlic.\n3. Add carrot, tomatoes, and tomato paste.\n4. Simmer for 20 minutes.\n5. Season well and serve over spaghetti.",
                "tags": "italian,pasta,beef,family",
                "image_name": "spaghetti_bolognese.jpg",
                "excerpt": "A hearty pasta dish with rich tomato sauce and tender beef mince.",
                "featured": 1,
            },
            {
                "title": "Pesto Chicken Penne",
                "slug": "pesto-chicken-penne",
                "cuisine": "Italian",
                "difficulty": "Easy",
                "cook_time": 25,
                "ingredients": "300 g penne\n2 chicken breasts\n1/3 cup basil pesto\n1/2 cup cream\nParmesan\nSpinach\nSalt and pepper",
                "instructions": "1. Cook the pasta.\n2. Pan-fry sliced chicken until cooked through.\n3. Stir in pesto, cream, and spinach.\n4. Toss with pasta and parmesan.\n5. Serve warm.",
                "tags": "italian,pasta,chicken,quick",
                "image_name": "pesto_chicken_penne.jpg",
                "excerpt": "Creamy pesto pasta for a quick weekday dinner.",
                "featured": 0,
            },
            {
                "title": "Veg Fried Rice",
                "slug": "veg-fried-rice",
                "cuisine": "Asian",
                "difficulty": "Easy",
                "cook_time": 20,
                "ingredients": "3 cups cold rice\n2 eggs\n1 cup mixed vegetables\n2 spring onions\n2 tbsp soy sauce\n1 tsp sesame oil\nGarlic",
                "instructions": "1. Scramble eggs and set aside.\n2. Stir-fry vegetables and garlic.\n3. Add rice, soy sauce, and sesame oil.\n4. Return eggs and toss well.\n5. Finish with spring onion.",
                "tags": "asian,vegetarian,rice,quick",
                "image_name": "veg_fried_rice.jpg",
                "excerpt": "A speedy rice dish packed with vegetables and flavour.",
                "featured": 1,
            },
            {
                "title": "Honey Soy Chicken Bowl",
                "slug": "honey-soy-chicken-bowl",
                "cuisine": "Asian",
                "difficulty": "Medium",
                "cook_time": 35,
                "ingredients": "Chicken thighs\n2 tbsp soy sauce\n1 tbsp honey\n1 tsp ginger\nRice\nBroccoli\nCarrot ribbons",
                "instructions": "1. Marinate chicken in soy, honey, and ginger.\n2. Bake or pan-fry until glazed.\n3. Steam vegetables.\n4. Serve over rice bowls.\n5. Spoon extra glaze on top.",
                "tags": "asian,chicken,bowl,meal-prep",
                "image_name": "honey_soy_chicken_bowl.jpg",
                "excerpt": "Sweet and savoury chicken bowls that are perfect for meal prep.",
                "featured": 0,
            },
            {
                "title": "Beef Tacos",
                "slug": "beef-tacos",
                "cuisine": "Mexican",
                "difficulty": "Easy",
                "cook_time": 25,
                "ingredients": "Taco shells\n500 g beef mince\n1 onion\nTaco seasoning\nLettuce\nTomato salsa\nCheese",
                "instructions": "1. Brown mince and onion.\n2. Stir in seasoning and a little water.\n3. Warm taco shells.\n4. Fill with meat, lettuce, salsa, and cheese.\n5. Serve immediately.",
                "tags": "mexican,beef,quick,family",
                "image_name": "beef_tacos.jpg",
                "excerpt": "Crunchy tacos filled with seasoned beef and fresh toppings.",
                "featured": 1,
            },
            {
                "title": "Chicken Quesadillas",
                "slug": "chicken-quesadillas",
                "cuisine": "Mexican",
                "difficulty": "Easy",
                "cook_time": 20,
                "ingredients": "Tortillas\nCooked chicken\nCheese\nCapsicum\nCorn\nSour cream\nSalsa",
                "instructions": "1. Spread chicken, vegetables, and cheese over tortilla.\n2. Top with a second tortilla.\n3. Toast in a pan until golden on both sides.\n4. Slice into wedges.\n5. Serve with sour cream and salsa.",
                "tags": "mexican,chicken,quick,sharing",
                "image_name": "chicken_quesadillas.jpg",
                "excerpt": "Golden toasted quesadillas that work well for lunch or dinner.",
                "featured": 0,
            },
            {
                "title": "Banana Pancakes",
                "slug": "banana-pancakes",
                "cuisine": "Breakfast",
                "difficulty": "Easy",
                "cook_time": 15,
                "ingredients": "1 banana\n2 eggs\n1/2 cup self-raising flour\n1/2 cup milk\nMaple syrup\nBerries",
                "instructions": "1. Mash banana.\n2. Whisk with eggs, flour, and milk.\n3. Cook spoonfuls in a non-stick pan.\n4. Flip when bubbles appear.\n5. Serve with berries and syrup.",
                "tags": "breakfast,vegetarian,quick,sweet",
                "image_name": "banana_pancakes.jpg",
                "excerpt": "Soft pancakes with banana flavour and fresh berries.",
                "featured": 0,
            },
            {
                "title": "Chocolate Mug Cake",
                "slug": "chocolate-mug-cake",
                "cuisine": "Dessert",
                "difficulty": "Easy",
                "cook_time": 5,
                "ingredients": "4 tbsp flour\n2 tbsp cocoa\n2 tbsp sugar\n3 tbsp milk\n2 tbsp oil\nChocolate chips",
                "instructions": "1. Mix dry ingredients in a mug.\n2. Add milk and oil.\n3. Stir until smooth.\n4. Microwave for 60 to 90 seconds.\n5. Rest briefly and enjoy.",
                "tags": "dessert,quick,chocolate,single-serve",
                "image_name": "chocolate_mug_cake.jpg",
                "excerpt": "A fast dessert for when you need something sweet immediately.",
                "featured": 0,
            },
            {
                "title": "Chicken Caesar Salad",
                "slug": "chicken-caesar-salad",
                "cuisine": "Salad",
                "difficulty": "Easy",
                "cook_time": 20,
                "ingredients": "Cos lettuce\nCooked chicken\nCroutons\nParmesan\nCaesar dressing\nBoiled eggs",
                "instructions": "1. Chop lettuce and chicken.\n2. Toss with dressing.\n3. Add croutons and parmesan.\n4. Top with sliced eggs.\n5. Serve chilled.",
                "tags": "salad,chicken,healthy,quick",
                "image_name": "chicken_caesar_salad.jpg",
                "excerpt": "A fresh and filling salad with crisp lettuce and parmesan.",
                "featured": 0,
            },
            {
                "title": "Avocado Toast",
                "slug": "avocado-toast",
                "cuisine": "Breakfast",
                "difficulty": "Easy",
                "cook_time": 10,
                "ingredients": "2 slices sourdough\n1 avocado\nLemon juice\nChilli flakes\nFeta\nSalt and pepper",
                "instructions": "1. Toast the sourdough.\n2. Mash avocado with lemon.\n3. Spread over toast.\n4. Top with feta and chilli flakes.\n5. Serve straight away.",
                "tags": "breakfast,vegetarian,healthy,quick",
                "image_name": "avocado_toast.jpg",
                "excerpt": "A bright and modern breakfast option that is quick to prepare.",
                "featured": 0,
            },
        ]

        for recipe in recipes:
            db.execute(
                """
                INSERT INTO recipes (
                    title, slug, cuisine, difficulty, cook_time, ingredients, instructions,
                    tags, image_name, excerpt, featured, created_by, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    recipe["title"],
                    recipe["slug"],
                    recipe["cuisine"],
                    recipe["difficulty"],
                    recipe["cook_time"],
                    recipe["ingredients"],
                    recipe["instructions"],
                    recipe["tags"],
                    recipe["image_name"],
                    recipe["excerpt"],
                    recipe["featured"],
                    admin_id,
                    now_iso(),
                ),
            )

        db.commit()

    post_count = db.execute("SELECT COUNT(*) AS total FROM blog_posts").fetchone()["total"]
    if post_count == 0:
        posts = [
            (
                "Healthy Lunchbox Ideas for Busy Students",
                "healthy-lunchbox-ideas",
                "Nutrition",
                "Quick ideas that keep students energised through the school day.",
                "Pack balanced lunches with protein, fruit, vegetables, and easy snacks. Small planning steps save time and money while supporting better concentration in class.",
            ),
            (
                "5 Tips for Hosting a Pizza Night at Home",
                "pizza-night-at-home",
                "Cooking Tips",
                "Turn a regular dinner into a community-style pizza night.",
                "Prepare toppings ahead of time, label ingredients clearly, and let everyone build their own pizza. This makes dinner interactive, inclusive, and fun for families and friends.",
            ),
            (
                "Seasonal Meals for Cooler Evenings",
                "seasonal-meals-cooler-evenings",
                "Seasonal Meals",
                "Comfort meals that still feel fresh and balanced.",
                "Think warm pasta bakes, soups, roast vegetables, and simple salads on the side. Seasonal cooking helps lower waste while using ingredients at their best.",
            ),
        ]

        db.executemany(
            """
            INSERT INTO blog_posts (title, slug, category, excerpt, content, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [(title, slug, category, excerpt, content, now_iso()) for title, slug, category, excerpt, content in posts],
        )
        db.commit()


# -----------------------------------------------------------------------------
# Security and request hooks
# -----------------------------------------------------------------------------
# These hooks enforce session timeout and add secure headers.
# Security headers help reduce attack surface in modern browsers.
# They are included because Task 2 focuses on secure architecture.
# -----------------------------------------------------------------------------

def register_request_hooks(flask_app: Flask) -> None:
    @flask_app.before_request
    def enforce_session_timeout() -> None:
        session.permanent = True

        # Ignore static files because they do not need session updates.
        # This reduces unnecessary work on CSS, JavaScript, and image requests.
        # It also keeps the request lifecycle efficient.
        if request.endpoint == "static":
            return None

        # Store the last activity time and expire inactive sessions gracefully.
        # This reduces the risk of session hijacking on shared computers.
        # Users are redirected with a friendly message instead of a crash.
        now = datetime.utcnow()
        last_seen = session.get("last_seen")
        if last_seen:
            last_seen_dt = datetime.fromisoformat(last_seen)
            if now - last_seen_dt > timedelta(minutes=SESSION_TIMEOUT_MINUTES):
                session.clear()
                flash("Your session expired after inactivity. Please sign in again.", "warning")
                return redirect(url_for("login"))
        session["last_seen"] = now.isoformat()
        return None

    @flask_app.after_request
    def add_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data: https:; "
            "script-src 'self' 'unsafe-inline'; "
            "frame-src https://www.youtube.com https://www.youtube-nocookie.com;"
        )
        return response


# -----------------------------------------------------------------------------
# Validation helpers
# -----------------------------------------------------------------------------
# These helpers improve input validation and help defend against malicious input.
# Strong validation also improves data quality and reduces accidental user errors.
# The sanitiser is intentionally strict for comments and text submissions.
# -----------------------------------------------------------------------------

def clean_text(value: str, max_length: int = 5000) -> str:
    value = (value or "").strip()
    value = value[:max_length]
    cleaned = bleach.clean(value, tags=[], attributes={}, strip=True)
    return re.sub(r"\s+", " ", cleaned).strip()



def slugify(value: str) -> str:
    value = clean_text(value, 120).lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or secrets.token_hex(4)



def now_iso() -> str:
    return datetime.utcnow().isoformat(timespec="seconds")



def is_locked_out(identifier: str, ip_address: str) -> bool:
    db = get_db()
    cutoff = (datetime.utcnow() - timedelta(minutes=LOGIN_WINDOW_MINUTES)).isoformat(timespec="seconds")

    attempts = db.execute(
        """
        SELECT COUNT(*) AS total
        FROM login_attempts
        WHERE created_at >= ?
          AND successful = 0
          AND (username_or_email = ? OR ip_address = ?)
        """,
        (cutoff, identifier, ip_address),
    ).fetchone()["total"]

    return attempts >= MAX_LOGIN_ATTEMPTS



def record_login_attempt(identifier: str, ip_address: str, successful: bool) -> None:
    db = get_db()
    db.execute(
        "INSERT INTO login_attempts (username_or_email, ip_address, successful, created_at) VALUES (?, ?, ?, ?)",
        (identifier, ip_address, 1 if successful else 0, now_iso()),
    )
    db.commit()



def log_action(actor: str, action: str, details: str) -> None:
    db = get_db()
    db.execute(
        "INSERT INTO audit_log (actor, action, details, created_at) VALUES (?, ?, ?, ?)",
        (actor, action, details, now_iso()),
    )
    db.commit()


# -----------------------------------------------------------------------------
# Authentication and role helpers
# -----------------------------------------------------------------------------
# These wrappers keep route code short and consistent.
# They also help enforce least privilege for admin-only routes.
# This aligns with the secure software architecture brief.
# -----------------------------------------------------------------------------

def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()



def login_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if current_user() is None:
            flash("Please sign in to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view_func(*args, **kwargs)

    return wrapped_view



def admin_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        user = current_user()
        if user is None or not user["is_admin"]:
            abort(403)
        return view_func(*args, **kwargs)

    return wrapped_view


# -----------------------------------------------------------------------------
# WTForms definitions
# -----------------------------------------------------------------------------
# Flask-WTF provides CSRF protection automatically on form submissions.
# This directly helps meet the requirement for CSRF protection.
# Each form also includes length checks to improve validation.
# -----------------------------------------------------------------------------

class RegisterForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=80)])
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=30)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8, max=128)])
    confirm_password = PasswordField(
        "Confirm password", validators=[DataRequired(), EqualTo("password")]
    )
    submit = SubmitField("Create account")

    def validate_username(self, field) -> None:
        username = clean_text(field.data, 30)
        if not re.fullmatch(r"[A-Za-z0-9_\-]+", username):
            raise ValidationError("Username can only contain letters, numbers, dashes, and underscores.")
        existing = get_db().execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
        if existing:
            raise ValidationError("That username is already taken.")

    def validate_email(self, field) -> None:
        email = clean_text(field.data, 120).lower()
        existing = get_db().execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
        if existing:
            raise ValidationError("That email is already registered.")


class LoginForm(FlaskForm):
    username_or_email = StringField("Username or email", validators=[DataRequired(), Length(max=120)])
    password = PasswordField("Password", validators=[DataRequired(), Length(max=128)])
    remember = BooleanField("Keep me signed in")
    submit = SubmitField("Sign in")


class TwoFactorForm(FlaskForm):
    token = StringField("Authentication code", validators=[DataRequired(), Length(min=6, max=6)])
    submit = SubmitField("Verify code")


class CommentForm(FlaskForm):
    content = TextAreaField("Comment", validators=[DataRequired(), Length(min=3, max=500)])
    submit = SubmitField("Post comment")


class RecipeForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(min=3, max=120)])
    cuisine = SelectField(
        "Cuisine",
        choices=[
            ("Italian", "Italian"),
            ("Asian", "Asian"),
            ("Mexican", "Mexican"),
            ("Breakfast", "Breakfast"),
            ("Dessert", "Dessert"),
            ("Salad", "Salad"),
        ],
    )
    difficulty = SelectField(
        "Difficulty",
        choices=[("Easy", "Easy"), ("Medium", "Medium"), ("Hard", "Hard")],
    )
    cook_time = StringField("Cook time (minutes)", validators=[DataRequired(), Length(max=4)])
    tags = StringField("Tags", validators=[DataRequired(), Length(max=180)])
    image_name = StringField("Image filename", validators=[Optional(), Length(max=120)])
    excerpt = TextAreaField("Short summary", validators=[DataRequired(), Length(min=10, max=240)])
    ingredients = TextAreaField("Ingredients", validators=[DataRequired(), Length(min=10, max=3000)])
    instructions = TextAreaField("Instructions", validators=[DataRequired(), Length(min=10, max=4000)])
    featured = BooleanField("Feature this recipe on the home page")
    submit = SubmitField("Save recipe")

    def validate_cook_time(self, field) -> None:
        if not str(field.data).isdigit():
            raise ValidationError("Cook time must be a number of minutes.")
        minutes = int(field.data)
        if minutes < 1 or minutes > 600:
            raise ValidationError("Cook time must be between 1 and 600 minutes.")


class SearchForm(FlaskForm):
    query = StringField("Search", validators=[Optional(), Length(max=120)])
    cuisine = SelectField(
        "Cuisine",
        choices=[("", "All cuisines"), ("Italian", "Italian"), ("Asian", "Asian"), ("Mexican", "Mexican"), ("Breakfast", "Breakfast"), ("Dessert", "Dessert"), ("Salad", "Salad")],
    )
    difficulty = SelectField(
        "Difficulty",
        choices=[("", "All difficulty levels"), ("Easy", "Easy"), ("Medium", "Medium"), ("Hard", "Hard")],
    )
    max_time = StringField("Max time", validators=[Optional(), Length(max=4)])
    submit = SubmitField("Filter")


# -----------------------------------------------------------------------------
# Route registration
# -----------------------------------------------------------------------------
# Keeping route setup inside one function makes startup easier to follow.
# Each route contains comments to explain the purpose of the logic.
# This helps meet the requirement for well-commented code.
# -----------------------------------------------------------------------------

def register_routes(flask_app: Flask) -> None:
    @flask_app.context_processor
    def inject_globals():
        return {
            "current_user": current_user(),
            "current_year": datetime.utcnow().year,
        }

    @flask_app.route("/")
    def home():
        db = get_db()

        # Featured recipes create a stronger first impression for the home page.
        # Latest recipes keep the landing page feeling current and active.
        # Blog highlights support the required cooking tips and advice section.
        featured = db.execute(
            "SELECT * FROM recipes WHERE featured = 1 ORDER BY created_at DESC LIMIT 3"
        ).fetchall()
        latest_recipes = db.execute(
            "SELECT * FROM recipes ORDER BY created_at DESC LIMIT 6"
        ).fetchall()
        blog_posts = db.execute(
            "SELECT * FROM blog_posts ORDER BY created_at DESC LIMIT 3"
        ).fetchall()
        cuisines = db.execute(
            "SELECT cuisine, COUNT(*) AS total FROM recipes GROUP BY cuisine ORDER BY cuisine"
        ).fetchall()
        return render_template(
            "home.html",
            featured=featured,
            latest_recipes=latest_recipes,
            blog_posts=blog_posts,
            cuisines=cuisines,
        )

    @flask_app.route("/recipes")
    def recipes():
        form = SearchForm(request.args, meta={"csrf": False})
        db = get_db()

        # Build the search query safely using parameter placeholders.
        # This prevents SQL injection because user input is never concatenated directly.
        # Each optional filter extends the query in a controlled way.
        sql = "SELECT * FROM recipes WHERE 1=1"
        params = []

        query = clean_text(form.query.data or "", 120)
        cuisine = clean_text(form.cuisine.data or "", 30)
        difficulty = clean_text(form.difficulty.data or "", 20)
        max_time = clean_text(form.max_time.data or "", 4)

        if query:
            sql += " AND (title LIKE ? OR tags LIKE ? OR excerpt LIKE ? OR ingredients LIKE ?)"
            wildcard = f"%{query}%"
            params.extend([wildcard, wildcard, wildcard, wildcard])
        if cuisine:
            sql += " AND cuisine = ?"
            params.append(cuisine)
        if difficulty:
            sql += " AND difficulty = ?"
            params.append(difficulty)
        if max_time.isdigit():
            sql += " AND cook_time <= ?"
            params.append(int(max_time))

        sql += " ORDER BY created_at DESC"
        recipes_list = db.execute(sql, params).fetchall()
        return render_template("recipes.html", recipes=recipes_list, form=form)

    @flask_app.route("/recipe/<slug>", methods=["GET", "POST"])
    def recipe_detail(slug: str):
        db = get_db()
        recipe = db.execute("SELECT * FROM recipes WHERE slug = ?", (slug,)).fetchone()
        if recipe is None:
            abort(404)

        form = CommentForm()

        # Comments require sign-in to reduce spam and support accountability.
        # Input is cleaned before storage to reduce XSS risk.
        # New comments are stored with a timestamp for moderation and auditing.
        if form.validate_on_submit():
            user = current_user()
            if user is None:
                flash("You need to sign in before posting a comment.", "warning")
                return redirect(url_for("login", next=request.path))

            content = clean_text(form.content.data, 500)
            db.execute(
                "INSERT INTO comments (recipe_id, user_id, content, approved, created_at) VALUES (?, ?, ?, ?, ?)",
                (recipe["id"], user["id"], content, 1, now_iso()),
            )
            db.commit()
            log_action(user["username"], "comment_created", f"Recipe {recipe['title']}")
            flash("Your comment was posted successfully.", "success")
            return redirect(url_for("recipe_detail", slug=slug))

        comments = db.execute(
            """
            SELECT comments.*, users.username
            FROM comments
            JOIN users ON users.id = comments.user_id
            WHERE comments.recipe_id = ? AND comments.approved = 1
            ORDER BY comments.created_at DESC
            """,
            (recipe["id"],),
        ).fetchall()

        share_url = request.url
        return render_template(
            "recipe_detail.html",
            recipe=recipe,
            comments=comments,
            form=form,
            share_url=quote_plus(share_url),
        )

    @flask_app.route("/blog")
    def blog():
        posts = get_db().execute("SELECT * FROM blog_posts ORDER BY created_at DESC").fetchall()
        return render_template("blog.html", posts=posts)

    @flask_app.route("/blog/<slug>")
    def blog_detail(slug: str):
        post = get_db().execute("SELECT * FROM blog_posts WHERE slug = ?", (slug,)).fetchone()
        if post is None:
            abort(404)
        return render_template("blog_detail.html", post=post)

    @flask_app.route("/about")
    def about():
        return render_template("about.html")

    @flask_app.route("/register", methods=["GET", "POST"])
    def register():
        user = current_user()
        if user is not None:
            return redirect(url_for("home"))

        form = RegisterForm()
        if form.validate_on_submit():
            db = get_db()
            full_name = clean_text(form.full_name.data, 80)
            username = clean_text(form.username.data, 30)
            email = clean_text(form.email.data, 120).lower()
            password = form.password.data

            # Basic password policy supports stronger authentication.
            # The checks are simple enough for students to understand.
            # This also aligns with the task requirement for secure authentication.
            if not re.search(r"[A-Z]", password) or not re.search(r"[a-z]", password) or not re.search(r"\d", password) or not re.search(r"[^A-Za-z0-9]", password):
                flash("Password must include upper case, lower case, number, and symbol.", "danger")
                return render_template("auth/register.html", form=form)

            db.execute(
                """
                INSERT INTO users (full_name, username, email, password_hash, is_admin, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (full_name, username, email, generate_password_hash(password), 0, now_iso()),
            )
            db.commit()
            log_action(username, "user_registered", email)
            flash("Your account has been created. Please sign in.", "success")
            return redirect(url_for("login"))

        return render_template("auth/register.html", form=form)

    @flask_app.route("/login", methods=["GET", "POST"])
    def login():
        user = current_user()
        if user is not None:
            return redirect(url_for("home"))

        form = LoginForm()
        if form.validate_on_submit():
            identifier = clean_text(form.username_or_email.data, 120).lower()
            ip_address = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")

            # Brute force mitigation checks recent failed attempts.
            # If too many failures happen, login is temporarily blocked.
            # This helps protect accounts from automated guessing attacks.
            if is_locked_out(identifier, ip_address):
                flash(
                    f"Too many failed login attempts. Please wait about {LOCKOUT_MINUTES} minutes and try again.",
                    "danger",
                )
                return render_template("auth/login.html", form=form)

            candidate = get_db().execute(
                "SELECT * FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?",
                (identifier, identifier),
            ).fetchone()

            if candidate is None or not check_password_hash(candidate["password_hash"], form.password.data):
                record_login_attempt(identifier, ip_address, False)
                flash("Invalid username/email or password.", "danger")
                return render_template("auth/login.html", form=form)

            # Clear the old session to reduce session fixation risk.
            # Store only essential details needed for the logged-in session.
            # If 2FA is enabled, finish authentication on the next page.
            record_login_attempt(identifier, ip_address, True)
            session.clear()
            session["pre_2fa_user_id"] = candidate["id"]
            session["remember_me"] = bool(form.remember.data)

            if candidate["two_factor_enabled"]:
                flash("Enter your authentication code to finish signing in.", "info")
                return redirect(url_for("verify_2fa"))

            complete_login(candidate)
            flash("Welcome back.", "success")
            return redirect(request.args.get("next") or url_for("home"))

        return render_template("auth/login.html", form=form)

    @flask_app.route("/verify-2fa", methods=["GET", "POST"])
    def verify_2fa():
        user_id = session.get("pre_2fa_user_id")
        if not user_id:
            return redirect(url_for("login"))

        user = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if user is None:
            session.clear()
            return redirect(url_for("login"))

        form = TwoFactorForm()
        if form.validate_on_submit():
            token = clean_text(form.token.data, 6)
            totp = pyotp.TOTP(user["two_factor_secret"])
            if not totp.verify(token, valid_window=1):
                flash("That authentication code was not valid.", "danger")
                return render_template("auth/verify_2fa.html", form=form)

            complete_login(user)
            flash("Two-factor authentication successful.", "success")
            return redirect(url_for("home"))

        return render_template("auth/verify_2fa.html", form=form)

    @flask_app.route("/account", methods=["GET", "POST"])
    @login_required
    def account():
        user = current_user()
        db = get_db()

        # Users can enable or disable 2FA from their account page.
        # The secret is shown so it can be added manually to an authenticator app.
        # A real deployment could extend this with a QR code.
        if request.method == "POST":
            action = request.form.get("action")
            if action == "enable_2fa" and not user["two_factor_enabled"]:
                secret = pyotp.random_base32()
                db.execute(
                    "UPDATE users SET two_factor_secret = ?, two_factor_enabled = 1 WHERE id = ?",
                    (secret, user["id"]),
                )
                db.commit()
                log_action(user["username"], "2fa_enabled", "Account settings")
                flash("Two-factor authentication enabled. Save your secret carefully.", "success")
            elif action == "disable_2fa" and user["two_factor_enabled"]:
                db.execute(
                    "UPDATE users SET two_factor_secret = NULL, two_factor_enabled = 0 WHERE id = ?",
                    (user["id"],),
                )
                db.commit()
                log_action(user["username"], "2fa_disabled", "Account settings")
                flash("Two-factor authentication disabled.", "warning")
            return redirect(url_for("account"))

        refreshed_user = db.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
        provisioning_uri = None
        if refreshed_user["two_factor_enabled"] and refreshed_user["two_factor_secret"]:
            provisioning_uri = pyotp.TOTP(refreshed_user["two_factor_secret"]).provisioning_uri(
                name=refreshed_user["email"], issuer_name="Bonnyrigg Pizza Blog"
            )
        return render_template("auth/account.html", user=refreshed_user, provisioning_uri=provisioning_uri)

    @flask_app.route("/logout")
    def logout():
        user = current_user()
        if user is not None:
            log_action(user["username"], "logout", "User logged out")
        session.clear()
        flash("You have been signed out.", "info")
        return redirect(url_for("home"))

    @flask_app.route("/admin")
    @admin_required
    def admin_dashboard():
        db = get_db()
        stats = {
            "users": db.execute("SELECT COUNT(*) AS total FROM users").fetchone()["total"],
            "recipes": db.execute("SELECT COUNT(*) AS total FROM recipes").fetchone()["total"],
            "comments": db.execute("SELECT COUNT(*) AS total FROM comments").fetchone()["total"],
            "blog_posts": db.execute("SELECT COUNT(*) AS total FROM blog_posts").fetchone()["total"],
        }
        recipes_list = db.execute("SELECT * FROM recipes ORDER BY created_at DESC").fetchall()
        comments = db.execute(
            """
            SELECT comments.*, recipes.title AS recipe_title, users.username
            FROM comments
            JOIN recipes ON recipes.id = comments.recipe_id
            JOIN users ON users.id = comments.user_id
            ORDER BY comments.created_at DESC LIMIT 10
            """
        ).fetchall()
        return render_template("admin/dashboard.html", stats=stats, recipes=recipes_list, comments=comments)

    @flask_app.route("/admin/recipe/new", methods=["GET", "POST"])
    @admin_required
    def admin_create_recipe():
        form = RecipeForm()
        if form.validate_on_submit():
            db = get_db()
            title = clean_text(form.title.data, 120)
            slug = slugify(title)

            existing = db.execute("SELECT id FROM recipes WHERE slug = ?", (slug,)).fetchone()
            if existing:
                slug = f"{slug}-{secrets.token_hex(2)}"

            db.execute(
                """
                INSERT INTO recipes (
                    title, slug, cuisine, difficulty, cook_time, ingredients, instructions,
                    tags, image_name, excerpt, featured, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    title,
                    slug,
                    clean_text(form.cuisine.data, 30),
                    clean_text(form.difficulty.data, 20),
                    int(form.cook_time.data),
                    clean_text(form.ingredients.data, 3000).replace(". ", ".\n"),
                    clean_text(form.instructions.data, 4000).replace(". ", ".\n"),
                    clean_text(form.tags.data, 180).lower(),
                    clean_text(form.image_name.data or "default_recipe.svg", 120),
                    clean_text(form.excerpt.data, 240),
                    1 if form.featured.data else 0,
                    current_user()["id"],
                    now_iso(),
                ),
            )
            db.commit()
            log_action(current_user()["username"], "recipe_created", title)
            flash("Recipe created successfully.", "success")
            return redirect(url_for("admin_dashboard"))
        return render_template("admin/recipe_form.html", form=form, heading="Create recipe")

    @flask_app.route("/admin/recipe/<int:recipe_id>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_edit_recipe(recipe_id: int):
        db = get_db()
        recipe = db.execute("SELECT * FROM recipes WHERE id = ?", (recipe_id,)).fetchone()
        if recipe is None:
            abort(404)

        form = RecipeForm(data=dict(recipe))
        if form.validate_on_submit():
            db.execute(
                """
                UPDATE recipes
                SET title = ?, cuisine = ?, difficulty = ?, cook_time = ?, ingredients = ?,
                    instructions = ?, tags = ?, image_name = ?, excerpt = ?, featured = ?
                WHERE id = ?
                """,
                (
                    clean_text(form.title.data, 120),
                    clean_text(form.cuisine.data, 30),
                    clean_text(form.difficulty.data, 20),
                    int(form.cook_time.data),
                    clean_text(form.ingredients.data, 3000).replace(". ", ".\n"),
                    clean_text(form.instructions.data, 4000).replace(". ", ".\n"),
                    clean_text(form.tags.data, 180).lower(),
                    clean_text(form.image_name.data or "default_recipe.svg", 120),
                    clean_text(form.excerpt.data, 240),
                    1 if form.featured.data else 0,
                    recipe_id,
                ),
            )
            db.commit()
            log_action(current_user()["username"], "recipe_updated", recipe["title"])
            flash("Recipe updated successfully.", "success")
            return redirect(url_for("admin_dashboard"))

        return render_template("admin/recipe_form.html", form=form, heading="Edit recipe")

    @flask_app.route("/admin/comment/<int:comment_id>/delete", methods=["POST"])
    @admin_required
    def admin_delete_comment(comment_id: int):
        db = get_db()
        db.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
        db.commit()
        log_action(current_user()["username"], "comment_deleted", f"Comment ID {comment_id}")
        flash("Comment deleted.", "info")
        return redirect(url_for("admin_dashboard"))

    @flask_app.errorhandler(400)
    def bad_request(_error):
        return render_template("errors/400.html"), 400

    @flask_app.errorhandler(403)
    def forbidden(_error):
        return render_template("errors/403.html"), 403

    @flask_app.errorhandler(404)
    def not_found(_error):
        return render_template("errors/404.html"), 404

    @flask_app.errorhandler(500)
    def server_error(_error):
        return render_template("errors/500.html"), 500


# -----------------------------------------------------------------------------
# Login completion helper
# -----------------------------------------------------------------------------
# This function finalises the authenticated session after password and 2FA checks.
# The session is kept intentionally small to reduce accidental information exposure.
# Logging the action improves traceability and accountability.
# -----------------------------------------------------------------------------

def complete_login(user) -> None:
    session.pop("pre_2fa_user_id", None)
    session["user_id"] = user["id"]
    session["username"] = user["username"]
    session["is_admin"] = bool(user["is_admin"])
    session["last_seen"] = datetime.utcnow().isoformat()
    log_action(user["username"], "login_success", "User logged in successfully")


# -----------------------------------------------------------------------------
# Main entry point
# -----------------------------------------------------------------------------
# The app can run with HTTPS in local testing using an adhoc certificate.
# This helps demonstrate SSL and HTTPS concepts for Task 2.
# Set USE_HTTPS=false if plain HTTP is preferred during debugging.
# -----------------------------------------------------------------------------

app = create_app()


if __name__ == "__main__":
    use_https = os.environ.get("USE_HTTPS", "false").lower() == "true"
    if use_https:
        app.run(debug=True, ssl_context="adhoc")
    else:
        app.run(debug=True)
