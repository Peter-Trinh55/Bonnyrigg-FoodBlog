# Bonnyrigg Pizza Blog - Logo + Full Recipe Version

This version is already updated so you only need to add your own images.

## What this version includes
- Bonnyrigg logo support in the navbar and footer
- pizza-only recipes
- seeded pizza recipes
- full ingredients for each recipe
- full cooking steps for each recipe
- recipe detail pages
- working comments on each recipe
- admin dashboard for adding more recipes
- image filename support for each recipe

## Where to add images
Put all images inside:

static/images/

### Required logo filename
bonnyrigg_logo.png

### Example pizza image filenames
margherita.jpg
pepperoni.jpg
bbq_chicken.jpg
vegetarian_supreme.jpg
hawaiian.jpg
meat_lovers.jpg
default_pizza.jpg

## How to connect pizza images
When adding a recipe in the admin dashboard, type the exact image filename in the 'image filename' field.

Example:
pepperoni.jpg

## How to run in VS Code
1. Open the folder in Visual Studio Code
2. Open a terminal
3. Run:

python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py

4. Open:
http://127.0.0.1:5000

## Admin login
Email: admin@bonnyriggpizza.local
Password: PizzaPass123

## Important note
The project includes empty placeholder image files. Replace them with your real logo and pizza photos using the same filenames for the easiest setup.
