import os
import secrets
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", secrets.token_hex(16))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bonnyrigg_pizza_blog.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

class Recipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    pizza_type = db.Column(db.String(50), nullable=False, default="Classic")
    difficulty = db.Column(db.String(20), nullable=False, default="Easy")
    cook_time = db.Column(db.Integer, nullable=False, default=20)
    description = db.Column(db.Text, nullable=False)
    ingredients = db.Column(db.Text, nullable=False)
    steps = db.Column(db.Text, nullable=False)
    image_filename = db.Column(db.String(150), nullable=False, default="default_pizza.jpg")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    comments = db.relationship("Comment", backref="recipe", lazy=True, cascade="all, delete-orphan")

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey("recipe.id"), nullable=False)
    author_name = db.Column(db.String(80), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

def get_current_user():
    if not session.get("user_id"):
        return None
    return User.query.get(session["user_id"])

def seed_data():
    if not User.query.filter_by(email="admin@bonnyriggpizza.local").first():
        db.session.add(
            User(
                username="admin",
                email="admin@bonnyriggpizza.local",
                password_hash=generate_password_hash("PizzaPass123"),
                is_admin=True,
            )
        )

    if Recipe.query.count() == 0:
        recipes = [
            Recipe(
                title="Classic Margherita Pizza",
                pizza_type="Classic",
                difficulty="Easy",
                cook_time=20,
                description="A simple pizza with tomato sauce, mozzarella and basil that is ideal for a clean, traditional flavour.",
                ingredients="2 pizza dough bases\n1 cup tomato pizza sauce\n250g mozzarella cheese, grated\n8 basil leaves\n1 tablespoon olive oil\nPinch of salt",
                steps="Preheat the oven to 220°C.\nPlace the pizza bases on trays or a pizza stone.\nSpread tomato sauce evenly over each base.\nSprinkle mozzarella across the top.\nAdd basil leaves and drizzle lightly with olive oil.\nBake for 10 to 12 minutes until the crust is golden.\nSlice and serve hot.",
                image_filename="margherita.jpg",
            ),
            Recipe(
                title="Pepperoni Feast Pizza",
                pizza_type="Meat",
                difficulty="Easy",
                cook_time=22,
                description="A bold pizza topped with pepperoni, rich tomato sauce and bubbling cheese for a classic takeaway-style result.",
                ingredients="2 pizza dough bases\n1 cup tomato pizza sauce\n300g mozzarella cheese, grated\n24 slices pepperoni\n1 teaspoon dried oregano\n1 tablespoon olive oil",
                steps="Preheat the oven to 220°C.\nPlace the dough bases onto trays.\nSpread tomato sauce over both bases.\nAdd mozzarella evenly over the sauce.\nLayer the pepperoni on top and sprinkle with oregano.\nBake for 12 minutes or until the cheese is melted and lightly browned.\nRest for 2 minutes before slicing.",
                image_filename="pepperoni.jpg",
            ),
            Recipe(
                title="BBQ Chicken Pizza",
                pizza_type="Specialty",
                difficulty="Medium",
                cook_time=25,
                description="This pizza combines smoky barbecue sauce, chicken, red onion and melted cheese for a richer flavour profile.",
                ingredients="2 pizza dough bases\n3/4 cup barbecue sauce\n250g cooked chicken, shredded\n250g mozzarella cheese, grated\n1/2 red onion, thinly sliced\n1 tablespoon parsley",
                steps="Preheat the oven to 220°C.\nSpread barbecue sauce over the pizza bases.\nScatter mozzarella over the sauce.\nAdd shredded chicken and red onion slices.\nBake for 12 to 14 minutes until cooked through.\nTop with parsley and serve.",
                image_filename="bbq_chicken.jpg",
            ),
            Recipe(
                title="Vegetarian Supreme Pizza",
                pizza_type="Vegetarian",
                difficulty="Medium",
                cook_time=24,
                description="A colourful vegetarian pizza with capsicum, mushroom, onion and olives, balanced by tomato sauce and cheese.",
                ingredients="2 pizza dough bases\n1 cup tomato pizza sauce\n250g mozzarella cheese, grated\n1/2 capsicum, sliced\n1/2 red onion, sliced\n1 cup mushrooms, sliced\n10 black olives, sliced\n1 teaspoon Italian herbs",
                steps="Preheat the oven to 220°C.\nSpread the tomato sauce over each pizza base.\nAdd mozzarella across the surface.\nArrange capsicum, onion, mushrooms and olives evenly.\nSprinkle with Italian herbs.\nBake for 12 minutes until the vegetables are slightly roasted.\nSlice and serve immediately.",
                image_filename="vegetarian_supreme.jpg",
            ),
            Recipe(
                title="Hawaiian Pizza",
                pizza_type="Classic",
                difficulty="Easy",
                cook_time=20,
                description="A soft and balanced pizza with ham, pineapple and cheese that combines salty and sweet flavours.",
                ingredients="2 pizza dough bases\n1 cup tomato pizza sauce\n250g mozzarella cheese, grated\n150g leg ham, diced\n1 cup pineapple pieces, drained",
                steps="Preheat the oven to 220°C.\nSpread tomato sauce over the pizza bases.\nTop with mozzarella cheese.\nScatter diced ham and pineapple evenly.\nBake for 10 to 12 minutes until the cheese melts and the crust turns golden.\nCool slightly before serving.",
                image_filename="hawaiian.jpg",
            ),
            Recipe(
                title="Meat Lovers Pizza",
                pizza_type="Meat",
                difficulty="Medium",
                cook_time=28,
                description="A filling pizza packed with pepperoni, ham, bacon and sausage for a hearty, high-protein option.",
                ingredients="2 pizza dough bases\n1 cup tomato pizza sauce\n300g mozzarella cheese, grated\n12 slices pepperoni\n100g ham, diced\n100g bacon, cooked\n100g cooked sausage, sliced",
                steps="Preheat the oven to 220°C.\nSpread tomato sauce on each pizza base.\nAdd the mozzarella cheese.\nTop with pepperoni, ham, bacon and sausage.\nBake for 12 to 14 minutes until the crust is crisp and the toppings are hot.\nAllow to rest briefly, then slice.",
                image_filename="meat_lovers.jpg",
            ),
        ]
        db.session.add_all(recipes)

    if Comment.query.count() == 0:
        db.session.add_all([
            Comment(recipe_id=1, author_name="Peter", body="The basil on this one makes it taste really fresh."),
            Comment(recipe_id=2, author_name="Henry", body="This pepperoni pizza feels like a proper takeaway style pizza."),
            Comment(recipe_id=3, author_name="An", body="The barbecue sauce gives it a really strong flavour."),
        ])

    db.session.commit()

@app.route("/")
def home():
    query = Recipe.query
    search = request.args.get("q", "").strip()
    pizza_type = request.args.get("pizza_type", "").strip()
    difficulty = request.args.get("difficulty", "").strip()

    if search:
        query = query.filter(
            Recipe.title.ilike(f"%{search}%")
            | Recipe.description.ilike(f"%{search}%")
            | Recipe.ingredients.ilike(f"%{search}%")
        )
    if pizza_type:
        query = query.filter_by(pizza_type=pizza_type)
    if difficulty:
        query = query.filter_by(difficulty=difficulty)

    recipes = query.order_by(Recipe.title.asc()).all()
    return render_template("home.html", recipes=recipes, current_user=get_current_user())

@app.route("/recipe/<int:recipe_id>", methods=["GET", "POST"])
def recipe_detail(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)

    if request.method == "POST":
        author_name = request.form.get("author_name", "").strip()
        body = request.form.get("body", "").strip()
        if not author_name or not body:
            flash("Please complete both comment fields.", "danger")
            return redirect(url_for("recipe_detail", recipe_id=recipe.id))
        db.session.add(Comment(recipe_id=recipe.id, author_name=author_name, body=body))
        db.session.commit()
        flash("Comment added successfully.", "success")
        return redirect(url_for("recipe_detail", recipe_id=recipe.id))

    ingredients_list = [line.strip() for line in recipe.ingredients.splitlines() if line.strip()]
    steps_list = [line.strip() for line in recipe.steps.splitlines() if line.strip()]

    return render_template(
        "recipe_detail.html",
        recipe=recipe,
        ingredients_list=ingredients_list,
        steps_list=steps_list,
        current_user=get_current_user(),
    )

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not username or not email or not password:
            flash("Please fill in all required fields.", "danger")
            return redirect(url_for("register"))
        if User.query.filter_by(email=email).first():
            flash("That email is already registered.", "danger")
            return redirect(url_for("register"))
        db.session.add(User(username=username, email=email, password_hash=generate_password_hash(password)))
        db.session.commit()
        flash("Account created successfully.", "success")
        return redirect(url_for("login"))
    return render_template("register.html", current_user=get_current_user())

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            session["user_id"] = user.id
            session["is_admin"] = user.is_admin
            flash("Logged in successfully.", "success")
            return redirect(url_for("admin_dashboard") if user.is_admin else url_for("home"))
        flash("Invalid login details.", "danger")
        return redirect(url_for("login"))
    return render_template("login.html", current_user=get_current_user())

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))

@app.route("/admin")
def admin_dashboard():
    if not session.get("is_admin"):
        flash("Admin access required.", "danger")
        return redirect(url_for("login"))
    return render_template(
        "admin.html",
        recipes=Recipe.query.order_by(Recipe.id.desc()).all(),
        users_count=User.query.count(),
        comments_count=Comment.query.count(),
        current_user=get_current_user(),
    )

@app.route("/admin/add", methods=["POST"])
def add_recipe():
    if not session.get("is_admin"):
        flash("Admin access required.", "danger")
        return redirect(url_for("login"))

    title = request.form.get("title", "").strip()
    pizza_type = request.form.get("pizza_type", "").strip()
    difficulty = request.form.get("difficulty", "").strip()
    description = request.form.get("description", "").strip()
    ingredients = request.form.get("ingredients", "").strip()
    steps = request.form.get("steps", "").strip()
    image_filename = request.form.get("image_filename", "").strip()
    try:
        cook_time = int(request.form.get("cook_time", "0"))
    except ValueError:
        cook_time = 0

    if not title or not pizza_type or not difficulty or not description or not ingredients or not steps or cook_time <= 0:
        flash("Please complete all recipe fields correctly.", "danger")
        return redirect(url_for("admin_dashboard"))

    if not image_filename:
        image_filename = "default_pizza.jpg"

    db.session.add(
        Recipe(
            title=title,
            pizza_type=pizza_type,
            difficulty=difficulty,
            cook_time=cook_time,
            description=description,
            ingredients=ingredients,
            steps=steps,
            image_filename=image_filename,
        )
    )
    db.session.commit()
    flash("Pizza recipe added successfully.", "success")
    return redirect(url_for("admin_dashboard"))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True)
